$("#contactForm").submit(function(event){
    // cancels the form submission
    event.preventDefault();

    submitForm();
});

function submitForm(){
    // Initiate Variables With Form Content
    var name = $("#name").val();
    var tel = $("#tel").val();
    var email = $("#email").val();
    var sub = $("#sub").val();
    var message = $("#message").val();

    $.ajax({
        type: "POST",
        url: "form-process.php",
        data: "name=" + name + "&tel=" + tel + "&email=" + email + "&sub=" + sub+ "&message=" + message,
        success : function(text){
            if (text == "success"){
                formSuccess();
            }
        }
    });

}


function formSuccess(){
    $( "#msgSubmit" ).removeClass( "success-message" );
}
