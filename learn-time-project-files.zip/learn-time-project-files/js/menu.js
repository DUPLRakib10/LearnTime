(function($) {
    
    "use strict";

	/* ==========================================================================
			Menu jQuery 
    ========================================================================== */

	$(document).ready(function(){	
		// Main Menu
		$(".main-menu ul.main-nav li:has(>ul)").addClass("has-children");
		
		if($(".main-menu ul.main-nav li").hasClass("has-children")){
			$(".main-menu ul.main-nav li.has-children").prepend('<span class="toggle-submenu"></span>')
		}
		
		if($(".header").hasClass("fixed")){
			$("body").addClass("header-fixed");
		}
		
		$('.main-menu-left .smallmenu-icon').on("click", function (){
			$("html").addClass("fix");
			$("body").addClass("fix");
			$(".main-menu").addClass("toggle-nav");
			$(".smallmenu-close").addClass("show-casing");
		});

		$('.smallmenu-close').on("click", function (){
			$("html").removeClass("fix");
			$("body").removeClass("fix");
			$(".main-menu").removeClass("toggle-nav");
			$(".smallmenu-close").removeClass("show-casing");
			$(".main-menu ul.main-nav li").removeClass("active");
			if($(".main-menu ul.main-nav li ul").hasClass("opened")){
				$(".main-menu ul.main-nav li ul").removeClass("opened").slideUp(200);
			}
		});

		$('.close-nav').on("click", function (){
			$("html").removeClass("fix");
			$("body").removeClass("fix");
			$(".main-menu").removeClass("toggle-nav");
			$(".smallmenu-close").removeClass("show-casing");
			$(".main-menu ul.main-nav li").removeClass("active");
			if($(".main-menu ul.main-nav li ul").hasClass("opened")){
				$(".main-menu ul.main-nav li ul").removeClass("opened").slideUp(200);
			}
		});
		
		$('.main-menu ul.main-nav li span').on("click", function (){
			if($(this).siblings('ul').hasClass('opened')){
				$(this).siblings('ul').removeClass('opened').slideUp(200);
				$(this).closest('li').removeClass('active');
			}
			else{
				$(this).siblings('ul').addClass('opened').slideDown(200);
				$(this).closest('li').addClass('active');
			}
		});

	
	});


	/* ==========================================================================
			call menu jQuery 
    ========================================================================== */

    // $(selector).attr(attribute,value);
    // The attr() method নির্বাচিত উপাদানগুলির attributes and values গুলি sets or returns করে
    
    $(window).resize(function() {
        if( $(this).width() > 991 ) {
            $('ul.sub-nav').attr('style', '');
        }
    });



	/* ==========================================================================
			stickyNav jQuery 
    ========================================================================== */

    window.stickyNav = {};
    var header = $(".header.fixed");

    $(window).on('scroll', function() {
        if (typeof stickyNav.scrollTop === 'undefined') {
            stickyNav.scrollTop = 0;
        }
        if ($(this).scrollTop() > stickyNav.scrollTop) {
            $(this).trigger('downscroll');
        } else {
            $(this).trigger('upscroll');
        }
        stickyNav.scrollTop = $(this).scrollTop();
    });

	$(window).scroll(function(){
		if( $(this).scrollTop() > 120 ) {
		 	header.addClass("trim");
		} else {
			header.removeClass("trim");
		}
	});

    function initStickyMenu() {
        stickyNav.stickyHeader = {};
        stickyNav.stickyHeader.elm = header;
        stickyNav.stickyHeader.tmp = {};
        stickyNav.stickyHeader.scrollTop = 0;
        stickyNav.stickyHeader.headerHeight = stickyNav.stickyHeader.elm.height();
        stickyNav.stickyHeader.limit = stickyNav.stickyHeader.headerHeight * 2;
        if ($('body').hasClass('admin-bar')) {
            stickyNav.stickyHeader.scrollTop = $('#wpadminbar').height();
        }
        $(window).on('downscroll', function() {
            stickyNav.stickyHeader.elm.not('.full').removeClass("scroll-down");
        }).on('upscroll', function() {
			if( $(this).scrollTop() > 120 ) {
	            stickyNav.stickyHeader.elm.addClass("scroll-down");
	        } else {
	        	stickyNav.stickyHeader.elm.removeClass("scroll-down");
	        }
        });
    }

	initStickyMenu();

})(jQuery);