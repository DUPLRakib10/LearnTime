(function($) {
  "use strict";

/* ==========================================================================
  accordion jQuery 
  ========================================================================== */
  
// $('.accordion > li:eq(0) a').addClass('active').next().slideDown();
  $('.accordion a').click(function (j) {
    var dropDown = $(this).closest('li').find('p');
    $(this).closest('.accordion').find('p').not(dropDown).slideUp();
    if ($(this).hasClass('active')) {
      $(this).removeClass('active');
    } else {
      $(this).closest('.accordion').find('a.active').removeClass('active');
      $(this).addClass('active');
    }
    dropDown.stop(false, true).slideToggle();
    j.preventDefault();
  });


// $('.accordion2 > li:eq(0) a').addClass('active').next().slideDown();
$('.accordion2 a').click(function (j) {
  var dropDown = $(this).closest('li').find('p');
  $(this).closest('.accordion2').find('p').not(dropDown).slideUp();
  if ($(this).hasClass('active')) {
    $(this).removeClass('active');
  } else {
    $(this).closest('.accordion2').find('a.active').removeClass('active');
    $(this).addClass('active');
  }
  dropDown.stop(false, true).slideToggle();
  j.preventDefault();
});

/* ==========================================================================
  owlCarousel jQuery 
  ========================================================================== */


  $('.home-slider').owlCarousel({
    loop: true,
    autoplay: true,
    items: 1,
    nav: false,
    smartSpeed: 200,
    dots: false,
    responsiveClass: true,
    navText: ['<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>'],
  });
  

  $(".home-slider-area").on('translate.owl.carousel', function () {
    $('.home-slider-area h3').removeClass('animated fadeInUp').css("opacity", "0");
    $('.home-slider-area h1').removeClass('animated zoomIn').css("opacity", "0");
    $('.home-slider-area P').removeClass('animated fadeInDown').css("opacity", "0");
  });

  $(".home-slider-area").on('translated.owl.carousel', function () {
    $('.home-slider-area h3').addClass('animated fadeInUp').css("opacity", "1");
    $('.home-slider-area h1').addClass('animated zoomIn').css("opacity", "1");
    $('.home-slider-area P').addClass('animated fadeInDown').css("opacity", "1");
  });

/* ==========================================================================
  owlCarousel jQuery 
  ========================================================================== */

  $('.lover-saying-slider').owlCarousel({
    loop: true,
    autoplay: true,
    items: 1,
    nav: false,
    smartSpeed: 200,
    dots: true,
    responsiveClass: true,
    navText: ['<i class="fas fa-arrow-left"></i>', '<i class="fas fa-arrow-right"></i>'],
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 2,
      },
      1000: {
        items: 3,
      }
    }
  });


/* ==========================================================================
  head-fixed jQuery 
  ========================================================================== */

  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $('.header.fixed').addClass('head-fixed');
    } else {
      $('.header.fixed').removeClass('head-fixed');
    }
  });




/* ==========================================================================
  scroll jQuery 
  ========================================================================== */

  $(".scroll-top").hide();

  $(document).on( 'click', '.scroll-top a', function () {
    $('body,html').animate({
      scrollTop: 0
    }, 800);
    return false;
  });

  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $('.scroll-top').fadeIn();
    } else {
      $('.scroll-top').fadeOut();
    }
  });



/* ==========================================================================
    smooth scrolling jQuery 
  ========================================================================== */

$('.main-nav li a[href*="#"]').not('[href="#"]'). not('[href="#0"]').click(function() {
      if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
          || location.hostname == this.hostname) {

          var target = $(this.hash);
          target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
             if (target.length) {
               $('html,body').animate({
                   scrollTop: target.offset().top - 80
              }, 500);
              return false;
          }
      }
  });


  /* ==========================================================================
      smooth scrolling jQuery hide
    ========================================================================== */

$('.main-nav li a').on('click',function() {
	$('.main-menu.toggle-nav').removeClass( "toggle-nav" );
  });


  /* ==========================================================================
      smooth scrolling jQuery footer quick-link 
    ========================================================================== */
$('.quick-link li a[href*="#"]').not('[href="#"]'). not('[href="#0"]').click(function() {
      if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') 
          || location.hostname == this.hostname) {

          var target = $(this.hash);
          target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
             if (target.length) {
               $('html,body').animate({
                   scrollTop: target.offset().top - 80
              }, 500);
              return false;
          }
      }
  });





}(jQuery));